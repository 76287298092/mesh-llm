//! Device-specific instruction qualification, separate from model execution.

pub mod ab_schedule;
pub mod attention_profile;
pub mod fp8_decode_schedule;
pub mod fp8_profile;
pub mod fp8_quantize_schedule;
pub mod nvfp4_decode_schedule;
pub mod nvfp4_profile;
#[cfg(any(test, target_os = "linux"))]
mod partition_audit;
mod native_mtp_q8_projection_cases;
pub use native_mtp_q8_projection_cases::Q8ProjectionCaseRange;

pub enum DecoderBlockKind {
    Gdn,
    Attention,
}
pub enum DecoderMlpKind {
    Nvfp4,
    Fp8,
}
pub struct DecoderLayer {
    pub prefix: String,
    pub state_prefix: String,
    pub block: DecoderBlockKind,
    pub mlp: DecoderMlpKind,
}
pub struct DecoderConfig {
    pub layers: Vec<DecoderLayer>,
    pub gdn_shape: GdnShape,
    pub attention_shape: ResidentAttentionShape,
    pub embedding_table: String,
    pub first_norm: String,
    pub final_norm: String,
    pub head_prefix: String,
    pub hidden: usize,
    pub vocabulary: usize,
    pub capacity: usize,
    pub state_layout: crate::engine::layout::Layout,
}
pub struct TargetBatchLoadRequest<'a> {
    pub ptx: &'a str,
    pub device: i32,
    pub artifact: &'a mut crate::artifact::model_source::ModelArtifact,
    pub objects: &'a [crate::artifact::schema::Object],
    pub config: &'a DecoderConfig,
    pub fixture: &'a crate::packages::qwen3_8_27b::target_batch_trial::Fixture,
}

pub fn target_batch_decode_check(request: TargetBatchLoadRequest<'_>) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_target_batch_entry::run(request);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = request;
        anyhow::bail!("Target batch trial requires Linux")
    }
}

pub fn model_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    reference: &crate::packages::qwen3_8_27b::model_reference::ModelReference,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_model_trial::run(ptx, device, artifact, objects, config, reference);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, reference);
        anyhow::bail!("Model trial requires Linux")
    }
}

pub fn model_profile(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    tokens: &[u32],
    teacher_token: Option<u32>,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_model_profile::run(
        ptx,
        device,
        artifact,
        objects,
        config,
        tokens,
        teacher_token,
    );
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (
            ptx,
            device,
            artifact,
            objects,
            config,
            tokens,
            teacher_token,
        );
        anyhow::bail!("Model profiling requires Linux")
    }
}

pub struct SpeculationRequest<'a> {
    pub tokens: &'a [u32],
    pub output_tokens: usize,
    pub depth: usize,
    pub repetitions: usize,
}
pub fn mtp_trial(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    reference: &crate::packages::qwen3_8_27b::mtp::Reference,
    request: &SpeculationRequest<'_>,
) -> anyhow::Result<serde_json::Value> {
    artifact.require_mtp()?;
    #[cfg(target_os = "linux")]
    return cuda::resident_mtp_trial::run(
        ptx, device, artifact, objects, config, reference, request,
    );
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, reference, request);
        anyhow::bail!("MTP trial requires Linux")
    }
}

/// One independent token stream for teacher-forced scoring.
pub struct ScoreStream {
    pub id: String,
    pub domain: String,
    pub tokens: Vec<u32>,
}
/// Fixed-window teacher-forced scoring request (context <= 512 for now).
pub struct ModelScoreRequest<'a> {
    pub corpus_id: &'a str,
    pub streams: &'a [ScoreStream],
    pub context: usize,
    pub stride: usize,
}
/// Receives encoded records for `(stream index, bytes)` after every window.
pub type ScoreSink<'a> = dyn FnMut(usize, &[u8]) -> std::io::Result<()> + 'a;
/// Score streams with fresh state per window; records go to `sink`.
pub fn model_score(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    request: &ModelScoreRequest<'_>,
    sink: &mut ScoreSink<'_>,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_model_score::run(ptx, device, artifact, objects, config, request, sink);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, request, sink);
        anyhow::bail!("Teacher-forced scoring requires Linux")
    }
}

/// Separate fixed-output ordinary Qwen benchmark; no change to existing bench limits.
pub struct ChunkedBenchRequest<'a> {
    pub tokens: &'a [u32],
    pub chunk_size: usize,
    pub output_tokens: usize,
    pub repetitions: usize,
}

/// Run real sequential prefill chunks, then ordinary decode. Updates `report`
/// incrementally so the caller can retain completed repetitions on failure.
/// The report must be a JSON object. Diagnostics are outside measured intervals.
pub fn qwen_chunked_benchmark(
    path: &std::path::Path,
    ptx: &str,
    device: i32,
    request: &ChunkedBenchRequest<'_>,
    report: &mut serde_json::Value,
) -> anyhow::Result<()> {
    #[cfg(target_os = "linux")]
    return cuda::stream_forward::chunked_bench::run(path, ptx, device, request, report);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (path, ptx, device, request, report);
        anyhow::bail!("Chunked benchmark requires Linux")
    }
}

pub struct ModelBenchRequest<'a> {
    pub tokens: &'a [u32],
    pub output_tokens: usize,
    pub repetitions: usize,
}
pub fn model_benchmark(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    request: &ModelBenchRequest<'_>,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_model_bench::run(ptx, device, artifact, objects, config, request);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, request);
        anyhow::bail!("Model benchmark requires Linux")
    }
}

/// Legacy versus stream forward equivalence request: prefill `tokens`, then
/// `decode_steps` greedy decode steps from identical zeroed sessions.
/// `MESH_SPECIALIZE_EXECUTION=graph` instead compares exact eager stream versus
/// actual whole-model graph replay and requires at least two decode steps.
pub struct StreamCheckRequest<'a> {
    pub tokens: &'a [u32],
    pub decode_steps: usize,
}
pub fn stream_forward_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &DecoderConfig,
    request: &StreamCheckRequest<'_>,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::stream_forward::check::run(ptx, device, artifact, objects, config, request);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, request);
        anyhow::bail!("Stream forward check requires Linux")
    }
}

pub struct ResidentAttentionShape {
    pub hidden: usize,
    pub intermediate: usize,
    pub query_heads: usize,
    pub kv_heads: usize,
    pub head_width: usize,
    pub rotary_dim: usize,
    pub rope_theta: f32,
}
pub struct ResidentAttentionConfig {
    pub shape: ResidentAttentionShape,
    pub prefix: String,
    pub state_prefix: String,
    pub table_name: String,
    pub vocabulary: usize,
    pub capacity: usize,
    pub state_layout: crate::engine::layout::Layout,
}
pub struct ResidentAttentionCase {
    pub tokens: Vec<u32>,
    pub reference: crate::qwen_attention_layer_reference::Layer,
}
pub fn resident_attention_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &ResidentAttentionConfig,
    cases: &[ResidentAttentionCase],
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_attention_trial::run(ptx, device, artifact, objects, config, cases);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, cases);
        anyhow::bail!("Resident attention trial requires Linux")
    }
}

pub struct GdnShape {
    pub hidden: usize,
    pub key_heads: usize,
    pub value_heads: usize,
    pub head_width: usize,
    pub intermediate: usize,
}
pub struct ResidentGdnConfig {
    pub shape: GdnShape,
    pub prefix: String,
    pub state_prefix: String,
    pub table_name: String,
    pub vocabulary: usize,
    pub state_layout: crate::engine::layout::Layout,
}
pub struct ResidentGdnCase {
    pub tokens: Vec<u32>,
    pub reference: crate::qwen_gdn_layer_reference::Layer,
}
pub fn resident_gdn_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    config: &ResidentGdnConfig,
    cases: &[ResidentGdnCase],
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_gdn_trial::run(ptx, device, artifact, objects, config, cases);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, config, cases);
        anyhow::bail!("Resident GDN trial requires Linux")
    }
}

pub struct Fp8MlpCase {
    pub prefix: String,
    pub rows: usize,
    pub width: usize,
    pub channels: usize,
    pub input: Vec<u16>,
    pub reference: crate::fp8_mlp_reference::Output,
}

pub fn fp8_mlp_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    cases: &[Fp8MlpCase],
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::fp8_mlp_trial::run(ptx, device, artifact, objects, cases);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, cases);
        anyhow::bail!("FP8 MLP GPU trial requires Linux")
    }
}

/// First operation used to validate views into a complete resident weight arena.
pub struct ResidentEntryInput {
    pub table_name: String,
    pub norm_name: String,
    pub tokens: Vec<u32>,
    pub width: usize,
    pub epsilon: f32,
    pub reference: crate::entry_reference::EntryReference,
}

pub fn residency_check(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    state_layout: &crate::engine::layout::Layout,
    entry: &ResidentEntryInput,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::residency::run(ptx, device, artifact, objects, state_layout, entry);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, state_layout, entry);
        anyhow::bail!("Qwen residency GPU trial requires Linux")
    }
}

/// Validated by the scalar reference before any GPU allocation or launch.
pub struct EmbeddingNormInput {
    pub table: Vec<u8>,
    pub weight: Vec<u8>,
    pub width: usize,
    pub epsilon: f32,
    pub batches: Vec<Vec<u32>>,
}

pub struct Fp8Projection {
    pub name: String,
    pub weights: Vec<u8>,
    pub scales: Vec<u8>,
    pub channels: usize,
}

pub struct AttentionInput {
    pub output_projection: Fp8Projection,
    pub post_attention_norm: ResidualNormWeights,
    pub mlp: Nvfp4Mlp,
    pub entry: EmbeddingNormInput,
    pub projections: [Fp8Projection; 3],
    pub q_norm: Vec<u8>,
    pub k_norm: Vec<u8>,
    pub query_heads: usize,
    pub kv_heads: usize,
    pub head_width: usize,
    pub rotary_dim: usize,
    pub rope_theta: f32,
    pub positions: Vec<Vec<u32>>,
}

pub fn attention_check(
    ptx: &str,
    device: i32,
    input: &AttentionInput,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::attention::run(ptx, device, input);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, input);
        anyhow::bail!("Qwen attention GPU trial requires Linux")
    }
}

pub struct ProjectionInput {
    pub entry: EmbeddingNormInput,
    pub projections: Vec<Fp8Projection>,
    pub bf16_projections: Vec<Bf16Projection>,
    pub convolution: Option<CausalConv4Weights>,
    pub gdn: Option<GdnWeights>,
    pub gdn_output: Option<GdnOutputWeights>,
    pub post_attention_norm: Option<ResidualNormWeights>,
    pub mlp: Option<Nvfp4Mlp>,
}

/// Logical packed weights; local FP8 scales divide by each global multiplier.
pub struct Nvfp4Projection {
    pub name: String,
    pub packed: Vec<u8>,
    pub scales: Vec<u8>,
    pub input_global: f32,
    pub weight_global: f32,
    pub channels: usize,
}

pub struct Nvfp4Mlp {
    pub gate: Nvfp4Projection,
    pub up: Nvfp4Projection,
    pub down: Nvfp4Projection,
}

pub struct ResidualNormWeights {
    pub weight: Vec<u8>,
    pub epsilon: f32,
}

pub struct GdnOutputWeights {
    pub z_projection: usize,
    pub norm: Vec<u8>,
    pub epsilon: f32,
    pub projection: Fp8Projection,
}

pub struct GdnWeights {
    pub a_projection: usize,
    pub b_projection: usize,
    pub key_heads: usize,
    pub value_heads: usize,
    pub width: usize,
    pub a_log: Vec<u8>,
    pub dt_bias: Vec<u8>,
}

/// Fixed-width causal convolution attached to one FP8 projection output.
pub struct CausalConv4Weights {
    pub projection: usize,
    pub weights: Vec<u8>,
}

pub struct Bf16Projection {
    pub name: String,
    pub weights: Vec<u8>,
    pub channels: usize,
}

pub fn projection_check(
    ptx: &str,
    device: i32,
    input: &ProjectionInput,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::projections::run(ptx, device, input);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, input);
        anyhow::bail!("Qwen projection GPU trial requires Linux")
    }
}

pub fn embedding_norm_check(
    ptx: &str,
    device: i32,
    input: &EmbeddingNormInput,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::embedding_norm::run(ptx, device, input);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, input);
        anyhow::bail!("Qwen entry GPU trial requires Linux")
    }
}

#[cfg(target_os = "linux")]
mod cuda;
#[cfg(any(target_os = "linux", test))]
mod fixtures;
#[cfg(any(target_os = "linux", test))]
#[cfg_attr(
    feature = "validation",
    allow(
        dead_code,
        reason = "Dense fixture materialization is used by the separate validation binary"
    )
)]
mod gemm_fixtures;
#[cfg(any(target_os = "linux", test))]
mod memory_fixtures;
#[cfg(any(target_os = "linux", test))]
mod nvfp4_layout;
#[cfg(any(target_os = "linux", test))]
mod ordinary_fixtures;
#[cfg(any(target_os = "linux", test))]
mod rms_norm_fixtures;

/// Snapshot the exact selected CUDA device and its current free memory. This
/// creates and destroys a context, but loads no model or device kernel.
pub fn device_probe(device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::device_probe(device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = device;
        anyhow::bail!("CUDA device admission trials require Linux")
    }
}

/// Run representative RMSNorm and tiled GEMM fixtures with resident GPU timing.
/// These are kernel workloads, not model prefill/decode measurements.
pub fn workload_probe(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::workloads::run(ptx, device, true);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("CUDA workload trials require Linux")
    }
}

/// Check each representative workload once, for bounded sanitizer execution.
pub fn workload_check(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::workloads::run(ptx, device, false);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("CUDA workload trials require Linux")
    }
}

/// Qualify shared-memory copies/loads, ordinary MMA, and register budgeting.
pub fn instruction_probe(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::instructions::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("CUDA instruction trials require Linux")
    }
}

/// JIT and numerically check the Rust NVFP4 single-warp probe on SM120.
/// Results are instruction evidence, not model throughput.
pub fn nvfp4_probe(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("CUDA instruction trials require Linux")
    }
}
#[path = "../kernels/nvptx/silu.rs"]
pub mod silu;

#[path = "../kernels/nvptx/exponential.rs"]
pub mod exponential;

#[path = "../kernels/nvptx/logprob_math.rs"]
pub mod logprob_math;

/// Check experimental projection kernels against independent synthetic references.
pub fn feature_projection_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::feature_projection_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Feature projection qualification requires Linux")
    }
}

/// Qualify experimental online attention on independent synthetic fixtures.
pub fn feature_attention_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::feature_attention_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Attention qualification requires Linux")
    }
}

/// Check fixed-address CUDA graph capture and replay.
pub fn feature_graph_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::feature_graph_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Graph qualification requires Linux")
    }
}

/// Check compact recurrence records against independent state prefixes.
pub fn feature_gdn_replay_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::feature_gdn_replay_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("GDN replay qualification requires Linux")
    }
}

/// Synthetic exact projection evidence; does not qualify model performance.
pub fn fp8_exact_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::fp8_exact_trial::standalone(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Exact FP8 qualification requires Linux")
    }
}

pub fn fp8_quantize_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::fp8_quantize_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("FP8 quantization qualification requires Linux")
    }
}

/// Check fused exact gate/up against independent and separate GPU controls.
pub fn feature_fusion_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::feature_fusion_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Fusion qualification requires Linux")
    }
}

/// Model-owned shape/metadata for the bounded workspace experiment.
pub struct MlpWorkspaceCase {
    pub prefix: String,
    pub width: usize,
    pub channels: usize,
    pub fp8: bool,
}
/// Compare identical resident MLP kernels under allocation/completion schedules.
pub fn mlp_workspace_trial(
    ptx: &str,
    device: i32,
    artifact: &mut crate::artifact::model_source::ModelArtifact,
    objects: &[crate::artifact::schema::Object],
    cases: &[MlpWorkspaceCase],
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::mlp_workspace_trial::run(ptx, device, artifact, objects, cases);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device, artifact, objects, cases);
        anyhow::bail!("MLP workspace trial requires Linux")
    }
}

/// Check GPU greedy selection against independent CPU ordering and rejection.
pub fn greedy_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::greedy_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("GPU greedy qualification requires Linux")
    }
}

/// Check the experimental A16 head schedule against independent logical arithmetic.
pub fn a16_head_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::a16_head_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("A16 head qualification requires Linux")
    }
}

/// Compare the tiled NVFP4 pipeline against independent arithmetic and native control.
pub fn nvfp4_pipeline_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::nvfp4_pipeline_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("NVFP4 pipeline qualification requires Linux")
    }
}

/// Check the PRMT expansion candidate against unchanged decode and the independent oracle.
pub fn nvfp4_prmt_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::nvfp4_decode_prmt_entry::synthetic(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("NVFP4 PRMT qualification requires Linux")
    }
}

/// Check verified layer-zero MLP weights without the legacy whole-model CPU reference.
pub fn nvfp4_prmt_real_trial(
    artifact: &std::path::Path,
    ptx: &str,
    device: i32,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::nvfp4_decode_prmt_entry::real(artifact, ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (artifact, ptx, device);
        anyhow::bail!("NVFP4 PRMT real-weight qualification requires Linux")
    }
}

pub fn native_mtp_residency_trial(
    artifact: &std::path::Path,
    device: i32,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::resident_native_mtp_trial::run(artifact, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (artifact, device);
        anyhow::bail!("Native MTP residency qualification requires Linux")
    }
}

pub fn native_mtp_q8_gemv_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_mtp_q8_operator::driver_entry::synthetic(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Native MTP Q8 GEMV qualification requires Linux")
    }
}

pub fn native_mtp_q8_fc_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_mtp_q8_fc_operator::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Native MTP Q8 FC qualification requires Linux")
    }
}

/// Run native Q8 FC qualification with the artifact-resident operator.
///
/// # Errors
/// Returns an error when the platform is unsupported or the operator trial fails.
pub fn native_mtp_q8_fc_resident_trial(
    artifact: &std::path::Path,
    ptx: &str,
    device: i32,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_mtp_q8_fc_operator::run_resident(artifact, ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (artifact, ptx, device);
        anyhow::bail!("Native MTP Q8 FC resident qualification requires Linux")
    }
}

pub fn native_mtp_q4_resident_trial(
    artifact: &std::path::Path,
    ptx: &str,
    device: i32,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_mtp_q4_operator::run_resident(artifact, ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (artifact, ptx, device);
        anyhow::bail!("Native MTP Q4 resident qualification requires Linux")
    }
}

/// Qualify native Q8 projections on each complete physical MTP parent.
///
/// # Errors
///
/// Returns an error when the qualification cannot run on the current platform.
/// Per-case failures are recorded in the returned report.
pub fn native_mtp_q8_projection_resident_trial(
    artifact: &std::path::Path,
    ptx: &str,
    device: i32,
) -> anyhow::Result<serde_json::Value> {
    native_mtp_q8_projection_resident_trial_range(NativeMtpQ8ProjectionResidentRequest {
        artifact,
        ptx,
        device,
        case_range: Q8ProjectionCaseRange::all(),
    })
}

pub struct NativeMtpQ8ProjectionResidentRequest<'a> {
    pub artifact: &'a std::path::Path,
    pub ptx: &'a str,
    pub device: i32,
    pub case_range: Q8ProjectionCaseRange,
}

pub fn native_mtp_q8_projection_resident_trial_range(
    request: NativeMtpQ8ProjectionResidentRequest<'_>,
) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return native_mtp_q8_projection_cases::run(request);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = request;
        anyhow::bail!("Native MTP Q8 resident projection qualification requires Linux")
    }
}

pub fn native_mtp_q4_head_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_mtp_q4_operator::driver_entry::synthetic(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Native MTP Q4 head qualification requires Linux")
    }
}

/// Qualify the standalone FP32 BF16 A/B decode candidate without changing dispatch.
pub fn bf16_ab_decode_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::bf16_ab_decode_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("BF16 A/B decode qualification requires Linux")
    }
}

pub mod attention_staged_plan;
pub mod attention_v2_plan;
pub mod attention_warp_plan;

/// Qualify the three-stage M=1 schedule; defaults to short cases and no timing.
pub fn attention_staged_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::attention_staged_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Staged FP64 attention qualification requires Linux")
    }
}

/// Qualify isolated exponential delivery against original attention bits and FP64 oracle.
pub fn attention_unrolled_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::attention_unrolled_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Unrolled attention qualification requires Linux")
    }
}

/// Standalone raw-FP64 old/new exponential bit probe, including NaN payloads.
pub fn exponential_unrolled_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::exponential_trial::standalone(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Exponential bit qualification requires Linux")
    }
}

/// Qualify exact-order warp attention against unchanged control bits and FP64 oracle.
pub fn attention_warp_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::attention_warp_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Warp FP64 attention qualification requires Linux")
    }
}

/// Qualify the standalone BF16 split-attention candidate; no resident dispatch change.
pub fn attention_v2_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::attention_v2_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Split attention qualification requires Linux")
    }
}

/// Qualify encoded embedding and FP32 GDN parameters with synthetic inputs only.
pub fn native_parameter_trial(ptx: &str, device: i32) -> anyhow::Result<serde_json::Value> {
    #[cfg(target_os = "linux")]
    return cuda::native_parameter_trial::run(ptx, device);
    #[cfg(not(target_os = "linux"))]
    {
        let _ = (ptx, device);
        anyhow::bail!("Native parameter qualification requires Linux")
    }
}
