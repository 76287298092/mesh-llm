use crate::{artifact::model_source::ModelArtifact, kernels::TargetBatchLoadRequest};
use anyhow::{Context, Result, ensure};
use serde::Deserialize;
use serde_json::json;
use std::path::Path;

#[derive(Debug, Deserialize)]
pub struct Fixture {
    pub prefix: Vec<u32>,
    pub target_tokens: [u32; 5],
    pub continuation: Vec<u32>,
    pub capacity: usize,
}

impl Fixture {
    pub fn parse(bytes: &[u8]) -> Result<Self> {
        let fixture: Self = serde_json::from_slice(bytes).context("parse target batch fixture")?;
        fixture.validate()?;
        Ok(fixture)
    }

    pub fn validate(&self) -> Result<()> {
        ensure!(!self.prefix.is_empty(), "target batch prefix is empty");
        ensure!(!self.continuation.is_empty(), "target batch continuation is empty");
        let rows = self.prefix.len().checked_add(5)
            .and_then(|rows| rows.checked_add(self.continuation.len()))
            .context("target batch fixture extent overflow")?;
        ensure!(rows <= self.capacity && self.capacity <= 512,
            "target batch fixture requires prefix + 5 + continuation <= capacity <= 512");
        let config = super::decoder::config(self.capacity)?;
        ensure!(self.prefix.iter().chain(&self.target_tokens).chain(&self.continuation)
            .all(|&token| usize::try_from(token).is_ok_and(|id| id < config.vocabulary)),
            "target batch fixture token is outside vocabulary");
        Ok(())
    }
}

pub struct Request<'a> {
    pub artifact: &'a Path,
    pub ptx: &'a str,
    pub device: i32,
    pub fixture: &'a Fixture,
}

pub fn run(request: Request<'_>) -> Result<serde_json::Value> {
    request.fixture.validate()?;
    ensure!(request.device >= 0, "device ordinal must be nonnegative");
    let mut artifact = ModelArtifact::open(request.artifact)?;
    let result = (|| {
        super::inventory::validate(artifact.directory())?;
        let objects = super::schedule::text_objects(artifact.directory())?;
        let config = super::decoder::config(request.fixture.capacity)?;
        crate::kernels::target_batch_decode_check(TargetBatchLoadRequest {
            ptx: request.ptx, device: request.device, artifact: &mut artifact,
            objects: &objects, config: &config, fixture: request.fixture,
        })
    })();
    let mut report = result.unwrap_or_else(|error| json!({
        "all_passed": false, "error": format!("{error:#}")
    }));
    report["identity"] = json!(artifact.identity());
    report["model_source"] = artifact.verification_report();
    report["native_mtp_admitted"] = json!(false);
    report["timing_claim"] = json!(false);
    Ok(report)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn fixture_accepts_metadata_when_extent_fits() {
        let bytes = br#"{"prefix":[1],"target_tokens":[2,3,4,5,6],"continuation":[7],"capacity":8,"metadata":{"source":"fixture"}}"#;
        let fixture = Fixture::parse(bytes.as_slice()).unwrap();
        assert_eq!(fixture.capacity, 8);
    }

    #[test]
    fn fixture_rejects_malformed_or_unbounded_requests() {
        let valid = json!({"prefix":[1],"target_tokens":[2,3,4,5,6],"continuation":[7],"capacity":7});
        for (field, value) in [
            ("prefix", json!([])), ("continuation", json!([])),
            ("target_tokens", json!([1,2,3,4])), ("prefix", json!([-1])),
            ("prefix", json!([248320])), ("capacity", json!(6)),
            ("capacity", json!(513)), ("capacity", json!("7")),
        ] {
            let mut input = valid.clone();
            input[field] = value;
            let result = Fixture::parse(&serde_json::to_vec(&input).unwrap());
            assert!(result.is_err(), "accepted invalid {field}");
        }
    }
}
